<?php
//$connect=mysql_connect("localhost","root","");
    //$db=mysql_select_db("wt",$connect) or die("could not conect");
echo "display donar profile";
?>