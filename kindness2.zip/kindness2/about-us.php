<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link rel="stylesheet" href="admin_login.css">
</head>
<body>

	<!-- header -->
	<header>
		<div id="search-bar">
			<div class="container">
				<div class="row">
					<form action="#" name="search" class="col-xs-12">
						<input type="text" name="search" placeholder="Type and Hit Enter"><i id="search-close" class="fa fa-close"></i>
					</form>
				</div>
			</div>
		</div>
		<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
									<li><a href="about-us.php">About Us</a></li>
									<li><a href="contact-us.php">Contact Us</a></li>
							<!--
							<li>
								<span>Blog</span>
								<ul class="submenu">
									<li><a href="blog-list.html">Blog List</a></li>
									<li><a href="blog-single.html">Blog Single</a></li>
								</ul>
							</li>-->
							<li>
								<a href="#">Admin</a>
							</li>
							<li>
								<a href="donor-login.php">Donor</a>
							</li>
							<li>
								<a href="contact-us.html">Volunteer</a>
							</li>
							<li>
								<a href="ngo.php">NGO</a>
							</li>
						</ul>
					</div>
					
				</div>
			</div>	
		</nav>
	</header>


	<!-- Banner -->
	<div class="page-banner">
		<div class="container">
			<div class="parallax-mask"></div>
			<div class="section-name">
				<h2>About Us</h2>
				<div class="short-text">
					<h5>Home<i class="fa fa-angle-double-right"></i>About Us</h5>
				</div>
			</div>
		</div>
	</div>
	
	<!-- about wrapper -->
	<div class="about-page-wrapper">
		<div class="description container">
			<div class="row ">
				<div class="col-md-6 ">
					<div class="image-wrapper">
						<img class="img-responsive" src="assets/img/featured-image-11.png" alt="">
					</div>
				</div>
				<div class="col-md-6 ">
					<div class="about-right-text">
						<div class="widget-title">
							<h4>Hi We Provide Worldwide Charity Service Since 1978</h4>
						</div>
						<p class="first">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus sapiente deleniti commodi provident veniam vitae blanditiis rerum temporibus totam est, omnis sint excepturi maiores iure similique. Sequi magni, suscipit laudantium velit. Excepturi sint placeat vel, porro, saepe ratione sunt natus, quod rem error ipsum ipsa.</p>
						<p class="second">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fuga voluptates dolor reprehenderit, deserunt, quibusdam repellat architecto blanditiis a, nulla inventore minima necessitatibus illum molestias, quas molestiae maiores tempora temporibus incidunt ea! Voluptate temporibus repellat nulla omnis nesciunt illum odit dicta fuga id!</p>
						<a href="#" class="btn btn-min btn-secondary"><span>Learn More</span></a>
					</div>
				</div>
			</div>
		</div>
		<!-- team -->
		<div class="team-wrapper">
			<div class="container">
				<div class="section-name one">
					<h2>our volunteers</h2>
					<div class="short-text">
						<h5>We are all times support them for their smile</h5>
					</div>
				</div>	
				
				<div class="team-members row">
					<div class="col-md-4 col-sm-6 col-xs-12">	
						<div class="single-member">
							<div class="best-volunteer">
								<div class="voluntee-image">
									<a href="#" title=""><img src="assets/img/best-volunte-1.jpg" alt=""></a>
								</div>
								<ul class="socials">
									<li><a href="#" title=""><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									<li><a href="#" title=""><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
									<li><a href="#" title=""><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
									
								</ul>
								<span><a href="#" title="">Cheif Director</a></span>
								<h2><a href="#" title="">Jonathan Greg</a></h2>
								<p>Lorem Jonathan Greg ipsum dolor sit amet, consectetur adipiscing elit, sed Jonathan Greg do...</p>
							</div>					
						</div>
					</div>
					<div class="col-md-4 col-sm-6 col-xs-12">	
						<div class="single-member">
							<div class="best-volunteer">
								<div class="voluntee-image">
									<a href="#" title=""><img src="assets/img/best-volunte-2.jpg" alt=""></a>
								</div>
								<ul class="socials">
									<li><a href="#" title=""><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									<li><a href="#" title=""><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
									<li><a href="#" title=""><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
									
								</ul>
								<span><a href="#" title="">Cheif Volunteer</a></span>
								<h2><a href="#" title="">Jennifier kalvin</a></h2>
								<p>Lorem Jonathan Greg ipsum dolor sit amet, consectetur adipiscing elit, sed Jonathan Greg do...</p>
							</div>					
						</div>
					</div>
					<div class="col-md-4 col-sm-6 col-xs-12 hidden-sm">	
						<div class="single-member">
							<div class="best-volunteer">
								<div class="voluntee-image">
									<a href="#" title=""><img src="assets/img/best-volunte-3.jpg" alt=""></a>
								</div>
								<ul class="socials">
									<li><a href="#" title=""><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									<li><a href="#" title=""><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
									<li><a href="#" title=""><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
									
								</ul>
								<span><a href="#" title="">Cheif Director</a></span>
								<h2><a href="#" title="">Mikel Willson</a></h2>
								<p>Lorem Jonathan Greg ipsum dolor sit amet, consectetur adipiscing elit, sed Jonathan Greg do...</p>
							</div>					
						</div>
					</div>	
				</div>	
			</div>	
		</div>	
		<div class="partners">
			<div class="container">
				<div class="row">
					<div id="partners-slider" class="owl-carousel owl-theme owl-transition clearfix">
						<div class="item">
							<a href="#"><img class="img-responsive" src="assets/img/others/logo-1.png" alt=""></a>
						</div>
						<div class="item">
							<a href="#"><img class="img-responsive" src="assets/img/others/logo-3.png" alt=""></a>
						</div>
						<div class="item">
							<a href="#"><img class="img-responsive" src="assets/img/others/logo-2.png" alt=""></a>
						</div>
						<div class="item">
							<a href="#"><img class="img-responsive" src="assets/img/others/logo-4.png" alt=""></a>
						</div>
						<div class="item">
						<a href="#"><img class="img-responsive" src="assets/img/others/logo-5.png" alt=""></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Foter -->
	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-sm-6">
					<div class="about widget clearfix">
						<div class="logo-wrap">
							<a href="index.html">kindness</a>
						</div>
						<p>At vero eos et accusamus et iusto odio dignis
						simos ducimus  qui blanditiis praesentiumlo 
						volupt </p>
						<div class="social-media-icons">
							<a href="#"><i class="fa fa-twitter"></i><span>Twitter</span></a>
							<a href="#"><i class="fa fa-google-plus"></i><span>Google +</span></a>
							<a href="#"><i class="fa fa-facebook"></i><span>Facebook</span></a>
							<a href="#"><i class="fa fa-linkedin"></i><span>Linkedin</span></a>
							<a href="#"><i class="fa fa-skype"></i><span>Skype</span></a>

						</div>
					</div>
				</div>
				<div class="col-md-2 col-sm-6 ">
					<div class="quick-links widget clearfix">
						<h4 class="title">Quick Links</h4>
						<div class="links">
							<a href="#"><i class="fa fa-angle-double-right"></i>About Us</a>
							<a href="#"><i class="fa fa-angle-double-right"></i>Forum</a>
							<a href="#"><i class="fa fa-angle-double-right"></i>Terms and Conditions</a>
							<a href="#"><i class="fa fa-angle-double-right"></i>Privacy Policy</a>
							<a href="#"><i class="fa fa-angle-double-right"></i>Blog</a>
							<a href="#"><i class="fa fa-angle-double-right"></i>Campains</a>
						</div>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 ">
					<div class="tags-outer widget clearfix">
						<h4 class="title">Tags</h4>
						<div class="tags">
							<a href="#"><span>Cause</span></a>
							<a href="#"><span>Lipsum</span></a>
							<a href="#"><span>Donation</span></a>
							<a href="#"><span>Charitable</span></a>
							<a href="#"><span>Homeless</span></a>
							<a href="#"><span>Blog</span></a>
							<a href="#"><span>Minimal</span></a>
							<a href="#"><span>Health</span></a>
							<a href="#"><span>Education</span></a>
							<a href="#"><span>LifStyle</span></a>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-6">
					<div class="subcribe widget clearfix">
						<h4 class="title">Subscribe</h4>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate provident amet reprehenderit!</p>
						<form action="#">
							<div class="field">
								<input type="email" name="e-mail" placeholder="Your E-mail">
							</div>
							<div class="field">
								<button class="btn btn-min btn-solid"><span>Subscibe</span></button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<div class="footer-bar">
			<div class="container">
				<h5>Copyright ©2017 Kindness. All Rights Reserved</h5>
			</div>
		</div>
	</footer>

	<!-- Scripts -->
	<script type="text/javascript" src="assets/js/jquery2.min.js"></script>
	<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="assets/js/jquery.meanmenu.js"></script>
	<script type="text/javascript" src="assets/js/progress-bar-appear.js"></script>
	<script type="text/javascript" src="assets/owl-carousel/owl.carousel.min.js"></script>
	<script type="text/javascript" src="assets/js/nivo-lightbox.min.js"></script>
	<script type="text/javascript" src="assets/js/isotope.min.js"></script>
	<script type="text/javascript" src="assets/js/countdown.js"></script>
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCBEypW1XtGLWpikFPcityAok8rhJzzWRw "></script>
	<script type="text/javascript" src="assets/js/gmaps.js"></script>
	<script type="text/javascript" src="assets/js/plugins.js"></script>
	<script type="text/javascript" src="assets/js/js.js"></script>

</body>
</html>