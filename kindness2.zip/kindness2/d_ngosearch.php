<html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
	<style>
body {
  font-family: "Lato", sans-serif;
}
.sidenav {
  width: 250px;
  position: fixed;
  z-index: 1;
  top: 150px;
  left: 10px;
  background: #c0c0c0;
  overflow-x: hidden;
  padding: 8px 0;
}
.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 25px;
  color: #FF1493;
  display: block;
  font-family: 'Acme', sans-serif;
}
.sidenav a:hover {
  color: #2196f3;
}
.main {
  margin-left: 280px; /* Same width as the sidebar + left position in px */
  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
  margin-top:50px;
}
.main font{
	font-family: 'Acme', sans-serif;
}
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
</head>
<body>
	<header>
	<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
								<span>Account</span>
								<ul class="submenu">
									<li><a href="donor-login.php">Log Out</a></li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</nav>
	</header><br><br><br><br>
	<?php
		$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
		$db=mysqli_select_db($conn,"charity2") or die("could not find db");
		$email=$_COOKIE["email"];
		setcookie("email",$email);
		$q="select d_name from donor_user where d_email='$email';";
		$arr=mysqli_query($conn,$q);
		$row=mysqli_fetch_array($arr,MYSQLI_BOTH);
		echo "<h1><b>Search for NGO's...</b>  ".$row['d_name']."</h1>"; 
	?>
	<div class="sidenav">
		<a href="#about">Cash Donation</a>
		<a href="d_goods_donation.php">Goods Donation</a>
		<a href="d_ngosearch.php">NGO Search</a>
		<a href="d_profile.php">Profile</a>
	</div>

	<div class="main">
	<form method="post" action="d_ngo_validate.php"><center>
	<h2><font color="#FF1493"><u>NGO SEARCH</u></font></h2><br>
		<h2><b>Enter NGO full name:
		<input type="text" name="ngo"/><br><br>
		<input type="submit" name="search" value="search"/></h2>
	</form>
	</div>
	</body>
</html>