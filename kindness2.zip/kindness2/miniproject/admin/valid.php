<?php
  //$connect=mysql_connect("localhost","root","");
  //$db=mysql_select_db("wt",$connect);
  $val=$_REQUEST["username"];
  $val1=$_REQUEST["pswd"];
  if(isset($_REQUEST["login"]))
  {
        if($val=="admin" && $val1=="admin")
	    {
		  echo "welcome $val";
		  header ('Location:admin.html');
	    }
	else
         {
            echo "Invalid username or password";
		
         }
    	
  }
?>
