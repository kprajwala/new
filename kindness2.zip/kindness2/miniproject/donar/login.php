<html>
<body>
<center>
<form method="post" action="login1.php">
<lable>username</lable>
<input type="text" name="username" required><br/>
<lable>password</lable>
<input type="password" name="password" required><br/>
<input type="submit" name="login" value="login"><br/>
</form>
</center>
</body>
<?php
     session_start();
     if(isset($_SESSION['x']))
     {
       if($_SESSION['x']!="")
        {
         echo "Wrong password";
         $_SESSION['x']="";
        }
     }
?>
</html>
