<?php
 //session_start();
//    $connect=mysql_connect("localhost","root","");
  //  $db=mysql_select_db("wt",$connect) or die("could not conect");
 if(isset($_REQUEST["SignUp"]))
 { 
    $us=$_REQUEST["username"];
    $pw=$_REQUEST["password"];
    $em=$_REQUEST["email"];
    $a=$_REQUEST["age"];
    //$q="INSERT INTO `login`(`username`, `password`, `email`, `age`) VALUES ('$us','$pw','$em','$a');";
    //mysql_query($q);
 echo "Signed up succesfully,please login";
 }

 header ('Location:login.php');
//mysql_close($connect);
?>