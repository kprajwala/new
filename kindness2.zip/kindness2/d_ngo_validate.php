<html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
	<style>
body {
  font-family: "Lato", sans-serif;
}
.sidenav {
  width: 250px;
  position: fixed;
  z-index: 1;
  top: 150px;
  left: 10px;
  background: #c0c0c0;
  overflow-x: hidden;
  padding: 8px 0;
}
.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 25px;
  color: #FF1493;
  display: block;
  font-family: 'Acme', sans-serif;
}
.sidenav a:hover {
  color: #2196f3;
}
.main {
  margin-left: 280px; /* Same width as the sidebar + left position in px */
  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
  margin-top:50px;
}
.main font{
	font-family: 'Acme', sans-serif;
}
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

  table {
   border-collapse: collapse;
   width: 100%;
   color: #588c7e;
   font-family: monospace;
   font-size: 25px;
   text-align: left;
     } 
  th {
   background-color: #588c7e;
   color: white;
    }
  tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
	<header>
	<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
								<span>Account</span>
								<ul class="submenu">
									<li><a href="donor-login.php">Log Out</a></li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</nav>
	</header><br><br><br><br>
	<?php
		$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
		$db=mysqli_select_db($conn,"charity2") or die("could not find db");
		$email=$_COOKIE["email"];
		setcookie("email",$email);
		$q="select d_name from donor_user where d_email='$email';";
		$arr=mysqli_query($conn,$q);
		$row=mysqli_fetch_array($arr,MYSQLI_BOTH);
		echo "<h1><b>Search for NGO's...</b>  ".$row['d_name']."</h1>"; 
	?>
	<div class="sidenav">
		<a href="#about">Cash Donation</a>
		<a href="d_goods_donation.php">Goods Donation</a>
		<a href="d_ngosearch.php">NGO Search</a>
		<a href="d_profile.php">Profile</a>
	</div>

	<div class="main">
	<form method="post" action="d_ngo_validate.php"><center>
	<h2><font color="#FF1493"><u>NGO SEARCH</u></font></h2><br>
		<h2>Enter NGO full name:
		<input type="text" name="ngo" required/><br><br>
		<input type="submit" name="search" value="search"/></h2>
	</form><br><br></center><center>
	<table>
		<th>NGO details</th>
	<?php
		$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
		$db=mysqli_select_db($conn,"charity2") or die("could not find db");
		//$s=var_dump($db);
		$ngo=$_REQUEST["ngo"];
		$q="select * from ngo_login where name='$ngo';";
		$result = $conn->query($q);
			if ($result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					echo "<tr><td>NGO name</td><td>".$row["name"]."</td></tr>".
						"<tr><td>NGO Email</td><td>".$row["email"]."</td></tr>".
						"<tr><td>Address</td><td>".$row["address"]."</td></tr>".
						"<tr><td>Phone Number</td><td>".$row["phone_no"]."</td></tr>".
						"<tr><td>City</td><td>".$row["city"]."</td></tr>".
						"<tr><td>State</td><td>".$row["state"]."</td></tr>";
						echo "</table><br><br>";
			if($ngo=="yatna ngo"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3806.725797990161!2d78.41947041482656!3d17.424941888056125!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb972b3819db73%3A0xa52c8a9c201a4e89!2sYatna+NGO!5e0!3m2!1sen!2sin!4v1563715035322!5m2!1sen!2sin" width="1300" height="400" frameborder="0" style="border:0" allowfullscreen></iframe></center>';
			}
			if($ngo=="abhaya foundation"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3807.002928906712!2d78.45416041482632!3d17.411647088064058!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb99bc7ed70b31%3A0x987577ba7eb192d0!2sAbhaya+Foundation!5e0!3m2!1sen!2sin!4v1563715267680!5m2!1sen!2sin" width="1300" height="400" frameborder="0" style="border:0" allowfullscreen></iframe></center>';
			}
			if($ngo=="shine ngo"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60925.039589445885!2d78.51289745539181!3d17.372634069073438!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb9f4d0e395087%3A0x1b725318e7002025!2sShine+Ngo!5e0!3m2!1sen!2sin!4v1563715993909!5m2!1sen!2sin" width="1300" height="400" frameborder="0" style="border:0" allowfullscreen></iframe></center>';
			}
			if($ngo=="share a smile ngo"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15228.648793638382!2d78.47485856977538!3d17.40400200000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb99dd82f5c7f1%3A0xfe1a295da517b505!2sShare+A+Smile+NGO!5e0!3m2!1sen!2sin!4v1563765387413!5m2!1sen!2sin" width="1300" height="400" frameborder="0" style="border:0" allowfullscreen></iframe></center>';
			}
			if($ngo=="suvidha ngo"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15226.940133275857!2d78.44223796977536!3d17.424499!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb973540000001%3A0xd8b9cdcc240a6e8!2sSuvidha+Ngo!5e0!3m2!1sen!2sin!4v1563776545140!5m2!1sen!2sin" width="1300" height="400" frameborder="0" style="border:0" allowfullscreen></iframe></center>';
			}
			if($ngo==""){
			echo '<center></center>';
			}
			if($ngo==""){
			echo '<center></center>';
			}
			if($ngo==""){
			echo '<center></center>';
			}
			if($ngo==""){
			echo '<center></center>';
			}
			if($ngo==""){
			echo '<center></center>';
			}
			if($ngo==""){
			echo '<center></center>';
			}
			}
			}
			else
			{
				echo "<tr><td>No NGO available with this name</td></tr>";
			}
		
	?>
	
	</div>
</body>
</html>