<?php
  $val=$_POST["uname"];
  $val1=$_POST["psw"];
  if(isset($_POST["Login"]))
  {
        if($val=="admin" && $val1=="admin")
	    {
		  echo "welcome ".$val;
		  header ('Location: admin.html');
	    }
	else
         {
            echo "Invalid username or password";
		
         }
    	
  }
?>
