<html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
	<style>
body {
  font-family: "Lato", sans-serif;
}
.sidenav {
  width: 250px;
  position: fixed;
  z-index: 1;
  top: 150px;
  left: 10px;
  background: #c0c0c0;
  overflow-x: hidden;
  padding: 8px 0;
}
.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 25px;
  color: #FF1493;
  display: block;
  font-family: 'Acme', sans-serif;
}
.sidenav a:hover {
  color: #2196f3;
}
.main {
  margin-left: 280px; /* Same width as the sidebar + left position in px */
  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
  margin-top:50px;
}
.main font{
	font-family: 'Acme', sans-serif;
}
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

  table {
   border-collapse: collapse;
   width: 100%;
   color: #588c7e;
   font-family: monospace;
   font-size: 25px;
   text-align: left;
     } 
  th {
   background-color: #588c7e;
   color: white;
    }
  tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
	<header>
	<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
								<span>Account</span>
								<ul class="submenu">
									<li><a href="donor-login.php">Log Out</a></li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</nav>
	</header><br><br><br><br>
	<?php
		$conn=mysqli_connect("localhost","root","","charity") or die("could not find conn");
		$db=mysqli_select_db($conn,"charity") or die("could not find db");
		$email=$_COOKIE["email"];
		setcookie("email",$email);
		$q="select name from donor where email='$email';";
		$arr=mysqli_query($conn,$q);
		$row=mysqli_fetch_array($arr,MYSQLI_BOTH);
		echo "<h1><b>Donate goods...</b>  ".$row['name']."</h1>"; 
	?>
	<div class="sidenav">
		<a href="#about">Cash Donation</a>
		<a href="d_goods_donation.php">Goods Donation</a>
		<a href="d_ngosearch.php">NGO Search</a>
		<a href="d_profile.php">Profile</a>
	</div>
	<div class="main">
		<form method="post" action="d_goods_donation_v.php"><center>
		<h2><font color="#FF1493"><u>SELECT MODE OF  DONATION..</u></font></h2><br>
		<h3>Goods You want to donate..<input type="text" name="goods" required/><br><br>
		<input type="radio" name="mode" value="mode1"/>  Donate to specific NGO<br><br>
		<input type="radio" name="mode" value="mode2"/>  Match the requirement<br><br></h3>
		<input type="submit" name="submit" value="submit"/></h2>
		
	</form>
	
	
	
	
	<br><br></center><center>
	<table>
	<?php
		$conn=mysqli_connect("localhost","root","","charity") or die("could not find conn");
		$db=mysqli_select_db($conn,"charity") or die("could not find db");
		$email=$_COOKIE["email"];
		$goods=$_COOKIE["goods"];
		$ngo=$_COOKIE["ngo"];
		$qr="select * from d_donation where email='$email' and items='$goods';";
		$val=mysqli_query($conn,$qr);
		if(mysqli_num_rows($val)==0)
		{
			$q="insert into d_donation (email,ngo,cash,items) values ('$email', '$ngo', 0, '$goods');";
			mysqli_query($conn,$q);
		}
		echo "Your details has been sent to the matched NGO ..$ngo....Thank You for donating";
		mail('$email','Thanks for Donating','Online Charity','From:onlinecharity2020@gmail.com');
	?>

	</center>
	</div>
</body>
</html>